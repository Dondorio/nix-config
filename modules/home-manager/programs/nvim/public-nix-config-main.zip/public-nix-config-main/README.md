# **❄️ apurplefrog's NixOS Configuration ❄️**
personal nixos & home-manager configurations :3

nix is pretty cool ngl
![Preview of my configuration](./preview.png)
